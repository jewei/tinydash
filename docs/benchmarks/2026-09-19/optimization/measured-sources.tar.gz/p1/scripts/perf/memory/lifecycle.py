"""Native Settings checks through the isolated release diagnostic overlay."""
import argparse
import importlib.util
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('memory_run', HERE/'run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)

def settings(script): return r.evaluate(script, 'settings')
def open_settings():
    r.command('settings')
    r.until(lambda: settings('return !!document.querySelector(".settings-fields") && !!window.__memoryBackend;'))

def section(name):
    settings(f'[...document.querySelectorAll("nav button")].find(button=>button.textContent.trim()==={json.dumps(name)}).click(); return true;')

def checkbox():
    return settings('return [...document.querySelectorAll("input[role=switch]")].find(input=>input.getAttribute("aria-label")==="Clear the search each time").checked;')

def edit_checkbox():
    return settings('const input=[...document.querySelectorAll("input[role=switch]")].find(input=>input.getAttribute("aria-label")==="Clear the search each time"); input.click(); return input.checked;')

def close_settings():
    r.command('close', window='settings')
    r.until(lambda: not any(w['label']=='settings' for w in r.command('status')['windows']))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--control', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    r.CONTROL = args.control.resolve()
    r.m.BASE = r.CONTROL
    pid, _ = r.launch(args.source.resolve(), 'real', False, r.CONTROL/'files')
    record = {'checks': [], 'started': time.strftime('%Y-%m-%dT%H:%M:%S%z')}
    def passed(name):
        record['checks'].append(name)
        print('PASS '+name, flush=True)
    try:
        r.until(lambda: r.command('status')['ready'])
        for cycle in range(20):
            open_settings()
            section('Shortcut')
            value = edit_checkbox()
            if cycle == 1:
                section('File search')
                # Test raw number input without invoking Save validation.
                settings('''const input=document.querySelector('input[aria-label="File limit"]'); input.value=""; input.dispatchEvent(new Event("input",{bubbles:true})); return true;''')
            elif cycle == 2:
                section('Search')
                r.until(lambda: settings('return document.querySelector("select[size]")?.options.length > 0;'))
                settings('const list=document.querySelector("select[size]"); list.value=list.options[0].value; list.dispatchEvent(new Event("change",{bubbles:true})); const text=document.querySelector("textarea"); text.focus(); text.value="  unfinished alias\\n\\n"; text.dispatchEvent(new Event("input",{bubbles:true})); return true;')
            elif cycle in [3,4]:
                # Restore valid settings before testing Save.
                settings('window.__memorySave=window.__memoryBackend.saveSettings; window.__memoryBackend.saveSettings=async(value)=>{await new Promise(resolve=>setTimeout(resolve,250)); '+('throw new Error("Injected Save failure");' if cycle==4 else 'return window.__memorySave(value);')+'}; [...document.querySelectorAll("button")].find(button=>button.textContent.trim()==="Save changes").click(); return true;')
            elif cycle == 5:
                settings('[...document.querySelectorAll("button")].find(button=>button.textContent.trim()==="Record new").click(); return true;')
                r.until(lambda: settings('return document.body.textContent.includes("Press your new shortcut");'))
            elif cycle in [6,7,8]:
                delay = 6000 if cycle == 7 else 250
                settings('window.__memoryCapture=window.__memoryBackend.captureSettingsSession; window.__memoryBackend.captureSettingsSession=async(...args)=>{'+('throw new Error("Injected capture failure");' if cycle==6 else f'await new Promise(resolve=>setTimeout(resolve,{delay})); return window.__memoryCapture(...args);')+'}; return true;')
                r.command('close', window='settings')
                if cycle == 8:
                    r.until(lambda: settings('return document.querySelector("main").inert;'))
                    r.command('settings')
                r.until(lambda: settings('return !document.querySelector("main").inert;'), timeout=10)
                assert any(w['label']=='settings' and w['visible'] for w in r.command('status')['windows'])
                if cycle == 7:
                    value = edit_checkbox()
                    time.sleep(1.5)
                    assert checkbox() == value
                settings('window.__memoryBackend.captureSettingsSession=window.__memoryCapture; return true;')
                passed(['capture failure preserves window','capture timeout rejects late state','reopen cancels pending close'][cycle-6])
            close_settings()
            open_settings()
            if cycle == 1:
                assert settings('''return document.querySelector('input[aria-label="File limit"]').value;''') == ''
                settings('''const input=document.querySelector('input[aria-label="File limit"]'); input.value="50000"; input.dispatchEvent(new Event("input",{bubbles:true})); return true;''')
                passed('invalid raw number survives destruction')
            elif cycle == 2:
                assert settings('return document.querySelector("textarea").value;') == '  unfinished alias\n\n'
                passed('open child editor and raw alias survive destruction')
            if cycle == 4:
                assert settings('return document.body.textContent.includes("Injected Save failure");')
                passed('failed Save state survives destruction')
            section('Shortcut')
            assert checkbox() == value
            close_settings()
            r.m.ui('show', pid)
            assert r.evaluate('return document.activeElement?.getAttribute("role") === "combobox";')
            r.command('hide')
            passed(f'cycle {cycle+1}: draft, native destruction, shortcut, focus')
        record['final_processes'] = r.m.members(pid)
    except Exception as error:
        record['error'] = str(error)
        raise
    finally:
        if pid in r.m.processes(): r.m.stop(pid)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(record, indent=2)+'\n')

if __name__ == '__main__': main()
