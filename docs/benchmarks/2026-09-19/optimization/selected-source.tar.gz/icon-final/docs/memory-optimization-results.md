# TinyDash memory optimization results

The selected implementation includes Settings window release, result selection before icon copying, and small icons loaded on demand. The first comparison and icon trials are complete. A native ownership check found retained Tao windows. The local dependency patch passes the native window-count check and the 100-visit Settings test. A later daily-use run crashed in WebKit during its twentieth Settings close. A separate 300-cycle test passed. Settings release is under further lifecycle investigation and is not yet accepted.

The work follows the [optimization plan](memory-optimization-plan.md). The base commit is `568972bbc92df37f2bbfd2951e8ab478b061e205`. The baseline also includes the uncommitted files that were present before this work. This baseline differs from the build in the original 163.1 MiB screenshot.

| Change                  | Resulting behavior                                                                                                     | Direct evidence                                                                                                                                           |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| P1, Settings            | Rust retains one editing session. Settings closes only after state capture and shortcut cleanup succeed.               | Twenty varied native cycles preserve input through actual window destruction.                                                                             |
| P2, result construction | Search selects results before it copies their icon data. The Settings catalog uses metadata only.                      | The frozen search fixture matches. A separate counter measures eliminated copies.                                                                         |
| P3a, icon demand        | Search returns icon identifiers. Visible results request images through a bounded cache.                               | Native checks cover cold requests, warm requests, delayed images, and image size. This data-URL format is selected for the final build.                       |
| P3b, binary icons       | Tauri returns PNG bytes. The frontend creates temporary Blob URLs and releases them when no visible result needs them. | The native bridge returns `ArrayBuffer`. The browser tests cover cancellation, capacity, identity, and scale changes. This trial is deferred because its memory benefit was not established. |

Settings capture includes invalid and partial input, raw folder and exclusion text, the saved-settings merge base, the selected section, scroll position, and application editor state. It also includes pending import details and errors. Close does not commit the draft or write it to disk. Draft recovery across app restarts is outside this change.

The close path freezes new edits and waits for an active Save or import to settle. Rust must acknowledge a consistent snapshot before the native window is destroyed. The snapshot limit is 16 MiB. A five-second deadline, failed capture, failed cleanup, or immediate reopen preserves the live editing session. A stale capture cannot close a newly opened session. Raw text no longer resets when a backend update leaves its saved value unchanged.

The native Settings checks include successful and failed Save operations, shortcut recording, capture failure, timeout, late acknowledgement, immediate reopen, appearance changes, an unapplied import preview, an imported appearance Save, external settings changes, Discard, and section and scroll restoration. A separate test build injects a native shortcut-registration failure. That injection is absent from every memory comparison build.

P2 keeps ranking, usage bonuses, pins, stable ties, and actions. The fixed corpus has 100 applications, tied scores, aliases, Unicode, a hidden application, usage data, and more than 30 pins. Seven query cases match results recorded from the original implementation. The fixture omits icon bytes but compares all other serialized result fields.

| Synthetic payload check        |  Original |      P2 |            Difference |
| ------------------------------ | --------: | ------: | --------------------: |
| Broad search, icon copies      |        99 |      30 |       69 fewer copies |
| Broad search, copied bytes     | 3,244,032 | 983,040 | 2,260,992 fewer bytes |
| Settings catalog, icon copies  |       100 |       0 |      100 fewer copies |
| Settings catalog, copied bytes | 3,276,800 |       0 | 3,276,800 fewer bytes |

Each synthetic icon contains 32 KiB. These counts measure copy work per operation. They do not measure retained physical footprint. The counter is test-only and is absent from performance runs.

| Icon resource                      |     Limit | Behavior when full                                                                   |
| ---------------------------------- | --------: | ------------------------------------------------------------------------------------ |
| Stored icon data URLs                  |     2 MiB | Evict the least recently used entries. Return an oversized image without caching it. |
| Cached entries, including misses   |       256 | Evict old entries.                                                                   |
| Active native loads                |         2 | Queue work within the queue limit.                                                   |
| Queued unique loads                |        64 | Cancel obsolete work. Keep the placeholder if capacity is still unavailable.         |
| Pending consumers                  |       128 | Return a capacity response.                                                          |
| Frontend entries for visible icons |        64 | Retain placeholders until the row mounts again.                                      |
| Requested pixel size               | 16 to 256 | Reject unsupported sizes.                                                            |

Requests for one image share work. A query change removes consumers that no longer need the image. A late response must match the current entry. Native extraction runs outside the search lock. Search completion does not await icon loading. At display scale 2, a 36-pixel row requests a 72-pixel image, and a 64-pixel preview requests a 128-pixel image.

Catalog generation, icon source revision, and requested size define the cache identity. Catalog refresh invalidates old images and requests. Unit tests check the byte, entry, active-job, queue, and consumer limits. They also check missing images, oversized images, cancellation, invalidation, and panic cleanup. Native tests check PNG dimensions, distinct application images, Finder custom icons, and custom icon replacement on a temporary directory.

The selected implementation returns small PNG data URLs through a separate icon command. Search responses contain stable icon keys. Icon commands accept only identifiers from the application catalog. Platforms without native icon support keep their existing fallback. Native desktop validation in this report is limited to macOS. The binary trial used Tauri binary responses and Blob URLs; those changes are absent from the selected build.

The Rust cache limit includes the stored base64 representation and data-URL prefix. It does not cap decoded WebKit images or macOS framework caches. The frontend keeps no persistent image cache. It drops each image reference when the last visible consumer leaves or the launcher hides.

| Validation                                                        | Result                          |
| ----------------------------------------------------------------- | ------------------------------- |
| Full Rust suite                                                   | 163 passed, 0 failed, 3 ignored |
| Full Playwright suite                                             | 137 passed                      |
| Type checking and production frontend build                       | Passed                          |
| Native icon test, run separately                                  | Passed                          |
| Twenty varied native Settings cycles                              | Passed                          |
| Native delayed-icon checks for both delivery formats              | Passed                          |
| Native keyboard use and warm reopening, screenshots and recording | Passed                          |

The release benchmark uses an isolated app identifier and data directory. It does not replace the installed TinyDash app. Clipboard capture reads synthetic text through a diagnostic hook. It does not read or change the system clipboard.

Physical footprint is the primary metric. Each sample includes the host and every helper assigned to that app by macOS process responsibility. RSS is recorded separately. Each state has a 30-second settling period and 31 samples at one-second intervals. A background sampler records workload peaks. Short allocations can occur between samples, so these are sampled peaks.

The comparison uses five fresh launches per configuration. The first comparison alternates build order. The final follow-up reuses the original baseline records and measures the selected build later. This limits the final comparison because time and system state can affect the result. Individual results, process membership, executable hashes, application corpus, environment records, and failed setup attempts are preserved. The controlled profile disables file roots, clipboard capture, and currency updates. The daily profile adds 50,000 files, file watching, 100 clipboard entries, pins, and cached currency data.

The user requested build cleanup when the disk became full. The cleanup overlapped daily trial 2 of the selected build. The complete baseline/candidate pair is repeated in fresh processes after cleanup. Both original records remain in the evidence. Other baseline records remain from the first comparison. Earlier records contain memory-pressure and swap readings but do not record free disk space. This is a further limit on comparisons across time. The repeated pair and later diagnostics record free disk space too. Compiler caches are removed; the native checks need only the app bundles.

Native query and warm-reopen measurements disable response tracing. Their result-ready checks use accessibility data. A separate screen recording confirms visible content and working input. These checks do not measure the exact time at which pixels reach the display.

The minimal-page comparison uses the same release binary, startup services, app catalog, native icon work, and backend requests. It verifies the completed page URL and marker. The minimal page receives and discards complete responses. The measured difference describes page-related cost under that workload. It does not establish removable memory or a universal WebKit minimum.

| Page, hidden footprint in MiB | Run 1 | Run 2 | Run 3 | Run 4 | Run 5 | Median |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Real launcher | 122.0 | 129.0 | 134.4 | 166.9 | 136.2 | 134.4 |
| Minimal page | 84.3 | 89.5 | 88.4 | 88.7 | 114.6 | 88.7 |

All ten runs completed the same 108 backend requests. Arguments, result titles, and serialized response lengths match between the pages. This first diagnostic includes an extra response-length trace. Its old field named `bytes` measures UTF-16 code units. The final comparison disables that serialization, so these page-control values are separate from its baseline. See the [minimal-page records](benchmarks/2026-09-19/optimization/minimal-summary.json).

P4 will use the repeated-use diagnostic to decide whether another frontend change is justified. Main-window release remains off. This implementation does not change the UI toolkit or establish a 50 MiB product target.

The full icon trial used five fresh processes per format. Each run included cold use, 100 warm queries, and enough unique images to force cache eviction. Hidden total footprint was 136.4 MiB at the median with data URLs (133.7 to 177.1 MiB), and 182.6 MiB with binary responses and Blob URLs (169.0 to 246.7 MiB). The ranges overlap. The binary change has no demonstrated memory benefit and is deferred.

| Icon workload | Data URL text, ms | Data URL decoded image, ms | Binary text, ms | Binary decoded image, ms |
| --- | ---: | ---: | ---: | ---: |
| Empty cache | 17.0 | 54.5 | 16.0 | 67.0 |
| Warm cache | 5.0 | 27.0 | 5.0 | 28.0 |
| After eviction | 4.0 | 39.0 | 4.5 | 35.0 |

These values are medians of five run medians. Each run has two empty-cache queries, 100 warm queries, and two queries after eviction. Cold and post-eviction timings therefore have few samples. The eviction sequence requests 496 distinct image identities and exceeds both cache budgets. These scripted query and image-decode timings are separate from native keyboard latency. With an injected 500 ms image delay, selected-format text appears in 2 to 3 ms while decoded images arrive in 545 to 547 ms. Text does not wait for image extraction.

The first window-destruction trial exposed a native ownership error. Its Settings allocation check found 1 native Tao window initially, 21 after 20 visits, and 41 after 40 visits. Only one WKWebView remained. The original baseline keeps its Settings window loaded. Tao 0.35.3 adds an extra retain to the owned window returned by its constructor. The [local dependency patch](../src-tauri/vendor/README.md) adopts that reference instead. With the patch, the native window count remains one at all three checkpoints. The corrected release build also passes all 20 varied Settings cycles.

The separate 100-visit check shows the corrected host footprint becoming stable after the first group. Each value below is a median of 31 physical-footprint samples after 30 seconds. These are two diagnostic processes, not five independent launches. The corrected process also uses the selected data-URL transport.

| Settings visits | Host before ownership fix, MiB | Corrected host, MiB | Corrected total, MiB |
| --- | ---: | ---: | ---: |
| 0 | 31.99 | 30.92 | 132.63 |
| 20 | 53.31 | 36.16 | 130.60 |
| 40 | 69.30 | 36.25 | 135.29 |
| 60 | 86.38 | 36.55 | 135.52 |
| 80 | 105.13 | 36.99 | 136.13 |
| 100 | 120.56 | 36.64 | 136.10 |

The dependency patch changes one ownership conversion in Tao 0.35.3. The published crate hash was verified before copying its source. All 119 published files remain present; only the macOS window source differs. The original licenses are retained. The patch requires review when Tao is updated. No change to the Cargo registry cache was made.

Cargo's final lockfile update also selects existing `windows-sys` 0.59 or 0.60 packages for several Windows dependencies. The complete lockfiles remain in the source records. The reported native checks cover macOS; they do not validate Windows or Linux desktop behavior.
