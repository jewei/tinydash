# Memory optimization evidence

The final native checks are in progress. This directory already contains the
source records and review patches. The final results will replace this notice.

`measured-sources.tar.gz` contains the frozen original source and the five
prepared builds from the first comparison. `selected-source.tar.gz` contains
the selected data-URL build with the Tao ownership fix. Build manifests record
source and executable SHA-256 values.

Apply the three patches in `selected-patches` in numerical order to the product
files from the frozen original source. They separate Settings, result-copy
reduction, and on-demand icons. Patch application and complete product-tree
hashes were checked. The first Settings patch includes the Tao fix.
`tao-ownership.patch` shows the only modified file in the published Tao crate.

The `patches` directory preserves the full investigation sequence, including
the binary icon trial that was deferred. Do not use that sequence as the final
selected implementation.
