import type { Appearance } from "./appearance";
import type { SettingsImport, SettingsValues, UpdateStatus } from "./bridge";

export interface AppEditorSession {
  filter: string;
  selected: string;
  aliases: string | null;
}

export interface SettingsSessionData {
  version: 1;
  draft: SettingsValues;
  saved: SettingsValues;
  section: string;
  folderMode: "default" | "custom" | "off";
  foldersText: string;
  excludedText: string;
  appearance: Appearance;
  savedAppearance: Appearance;
  scroll: number;
  appEditor: AppEditorSession;
  historyLimitText?: string;
  fileLimitText?: string;
  pendingImport?: SettingsImport;
  clearOpen: boolean;
  clearKeepPinned: boolean;
  error?: string;
  dialogError?: string;
  status: string;
  updateStatus?: UpdateStatus;
}

export interface SettingsSessionSnapshot {
  revision: number;
  data: SettingsSessionData;
}
