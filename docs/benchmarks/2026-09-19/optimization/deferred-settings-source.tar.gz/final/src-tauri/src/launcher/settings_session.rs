//! Keep an editing session outside the Settings webview. Never commit a draft.
use std::{sync::Mutex, time::Duration};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use tauri::{AppHandle, Emitter, Manager, WebviewWindow};
use tokio::sync::oneshot;

// Two settings copies can contain 512 app IDs and 16 aliases per app. Allow
// those copies, an import preview, and raw editor text. Oversized drafts stay
// in the live window; we never truncate them to meet this limit.
const MAX_SESSION_BYTES: usize = 16 * 1024 * 1024;
const CLOSE_TIMEOUT: Duration = Duration::from_secs(5);

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Snapshot {
    revision: u64,
    data: Value,
}

struct Pending {
    generation: u64,
    captured: bool,
    _cancel: oneshot::Sender<()>,
}

#[derive(Default)]
struct Session {
    generation: u64,
    pending: Option<Pending>,
    snapshot: Option<Snapshot>,
}

impl Session {
    fn begin(&mut self) -> Option<(u64, oneshot::Receiver<()>)> {
        if self.pending.is_some() {
            return None;
        }
        self.generation += 1;
        let (cancel, receiver) = oneshot::channel();
        self.pending = Some(Pending {
            generation: self.generation,
            captured: false,
            _cancel: cancel,
        });
        Some((self.generation, receiver))
    }

    fn current(&self, generation: u64) -> bool {
        self.pending
            .as_ref()
            .is_some_and(|pending| pending.generation == generation)
    }

    fn cancel(&mut self, generation: Option<u64>) -> Option<u64> {
        if generation.is_some_and(|generation| !self.current(generation)) {
            return None;
        }
        self.pending.take().map(|pending| pending.generation)
    }

    fn capture(&mut self, generation: u64, snapshot: Snapshot) -> Result<bool, String> {
        if !self.current(generation) {
            return Ok(false);
        }
        if self
            .snapshot
            .as_ref()
            .is_some_and(|saved| snapshot.revision <= saved.revision)
        {
            return Err(
                "The Settings snapshot is out of date. Keep this window open and try again.".into(),
            );
        }
        if snapshot.data["version"] != 1
            || !snapshot.data["draft"].is_object()
            || !snapshot.data["saved"].is_object()
        {
            return Err(
                "Could not preserve the Settings session. Your changes are still in this window."
                    .into(),
            );
        }
        if serde_json::to_vec(&snapshot)
            .map_err(|e| e.to_string())?
            .len()
            > MAX_SESSION_BYTES
        {
            return Err("The Settings draft is too large to close safely. Save or shorten it, then try again.".into());
        }
        self.snapshot = Some(snapshot);
        self.pending.as_mut().unwrap().captured = true;
        Ok(true)
    }
}

#[derive(Default)]
pub struct SettingsSession {
    session: Mutex<Session>,
    // Serialize native creation and destruction, without blocking the UI loop.
    operation: tokio::sync::Mutex<()>,
}

fn settings_only(window: &WebviewWindow) -> Result<(), String> {
    if window.label() == "settings" {
        Ok(())
    } else {
        Err("This operation requires Settings.".into())
    }
}

async fn restore_shortcuts(app: &AppHandle) -> Result<(), String> {
    let app = app.clone();
    tauri::async_runtime::spawn_blocking(move || {
        super::preferences::finish_settings_recording(&app)
    })
    .await
    .map_err(|e| e.to_string())?
}

async fn cancel(app: &AppHandle, generation: u64, error: Option<String>) -> Result<(), String> {
    let cancelled = app
        .state::<SettingsSession>()
        .session
        .lock()
        .unwrap()
        .cancel(Some(generation));
    if cancelled.is_none() {
        return Ok(());
    }
    let restored = restore_shortcuts(app).await;
    let error = restored.as_ref().err().cloned().or(error);
    if let Some(window) = app.get_webview_window("settings") {
        let _ = window.emit(
            "settings-close-cancelled",
            serde_json::json!({"generation": generation, "error": error}),
        );
    }
    restored
}

pub fn request_close(app: &AppHandle) {
    let Some((generation, receiver)) = app
        .state::<SettingsSession>()
        .session
        .lock()
        .unwrap()
        .begin()
    else {
        return;
    };
    let app = app.clone();
    tauri::async_runtime::spawn(async move {
        let sent = app
            .get_webview_window("settings")
            .ok_or_else(|| "Settings window is unavailable.".to_string())
            .and_then(|window| {
                window
                    .emit("settings-close-requested", generation)
                    .map_err(|e| e.to_string())
            });
        if let Err(error) = sent {
            let _ = cancel(&app, generation, Some(error)).await;
        } else if tokio::time::timeout(CLOSE_TIMEOUT, receiver).await.is_err() {
            let _ = cancel(
                &app,
                generation,
                Some(
                    "Settings could not close in time. Your changes are still in this window."
                        .into(),
                ),
            )
            .await;
        }
    });
}

pub async fn open(app: AppHandle) -> Result<(), String> {
    let state = app.state::<SettingsSession>();
    // Cancel before waiting for native cleanup. A new activation wins over a
    // close that has captured state but has not destroyed the window yet.
    let cancelled = state.session.lock().unwrap().cancel(None);
    if let Some(generation) = cancelled {
        if let Some(window) = app.get_webview_window("settings") {
            let _ = window.emit(
                "settings-close-cancelled",
                serde_json::json!({"generation": generation, "error": null}),
            );
        }
        restore_shortcuts(&app).await?;
    }
    let _operation = state.operation.lock().await;
    super::preferences::show_settings_window(&app)
}

#[tauri::command]
pub fn get_settings_session(
    window: WebviewWindow,
    app: AppHandle,
) -> Result<Option<Snapshot>, String> {
    settings_only(&window)?;
    Ok(app
        .state::<SettingsSession>()
        .session
        .lock()
        .unwrap()
        .snapshot
        .clone())
}

#[tauri::command]
pub fn capture_settings_session(
    window: WebviewWindow,
    app: AppHandle,
    generation: u64,
    snapshot: Snapshot,
) -> Result<bool, String> {
    settings_only(&window)?;
    app.state::<SettingsSession>()
        .session
        .lock()
        .unwrap()
        .capture(generation, snapshot)
}

#[tauri::command]
pub async fn cancel_settings_close(
    window: WebviewWindow,
    app: AppHandle,
    generation: u64,
) -> Result<(), String> {
    settings_only(&window)?;
    cancel(&app, generation, None).await
}

#[tauri::command]
pub async fn finish_settings_close(
    window: WebviewWindow,
    app: AppHandle,
    generation: u64,
) -> Result<bool, String> {
    settings_only(&window)?;
    let state = app.state::<SettingsSession>();
    let _operation = state.operation.lock().await;
    let captured = state
        .session
        .lock()
        .unwrap()
        .pending
        .as_ref()
        .is_some_and(|pending| pending.generation == generation && pending.captured);
    if !captured {
        return Ok(false);
    }
    if let Err(error) = restore_shortcuts(&app).await {
        let _ = cancel(&app, generation, Some(error.clone())).await;
        return Err(error);
    }
    // No await between the final generation check and the destruction request.
    let result = {
        let mut session = state.session.lock().unwrap();
        if !session.current(generation) {
            return Ok(false);
        }
        let result = window.destroy();
        if result.is_ok() {
            session.cancel(Some(generation));
        }
        result
    };
    if let Err(error) = result {
        let _ = cancel(&app, generation, Some(error.to_string())).await;
        return Err(error.to_string());
    }
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn snapshot(revision: u64) -> Snapshot {
        Snapshot {
            revision,
            data: json!({"version":1,"draft":{"fileSearchLimit":0},"saved":{},"foldersText":"  unfinished\n"}),
        }
    }

    #[test]
    fn retains_invalid_draft_without_committing_it() {
        let mut session = Session::default();
        let (generation, _cancelled) = session.begin().unwrap();
        assert!(session.capture(generation, snapshot(1)).unwrap());
        session.cancel(Some(generation));
        assert_eq!(
            session.snapshot.unwrap().data["draft"]["fileSearchLimit"],
            0
        );
    }

    #[test]
    fn reopen_rejects_a_late_capture_and_does_not_replace_newer_input() {
        let mut session = Session::default();
        let (old, mut cancelled) = session.begin().unwrap();
        assert!(session.begin().is_none());
        session.cancel(None);
        assert_eq!(
            cancelled.try_recv(),
            Err(oneshot::error::TryRecvError::Closed)
        );
        let (new, _receiver) = session.begin().unwrap();
        assert!(session.capture(new, snapshot(2)).unwrap());
        assert!(!session.capture(old, snapshot(1)).unwrap());
        assert_eq!(session.snapshot.as_ref().unwrap().revision, 2);
        assert!(session.cancel(Some(old)).is_none());
        assert!(session.current(new));
    }

    #[test]
    fn failed_capture_keeps_previous_snapshot_and_pending_window() {
        let mut session = Session::default();
        let (first, _receiver) = session.begin().unwrap();
        session.capture(first, snapshot(1)).unwrap();
        session.cancel(Some(first));
        let (second, _receiver) = session.begin().unwrap();
        assert!(session.capture(second, snapshot(1)).is_err());
        let mut large = snapshot(2);
        large.data["foldersText"] = Value::String("x".repeat(MAX_SESSION_BYTES));
        assert!(session.capture(second, large).is_err());
        assert!(session.current(second));
        assert!(!session.pending.as_ref().unwrap().captured);
        assert_eq!(session.snapshot.unwrap().revision, 1);
    }
}
