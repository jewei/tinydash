# TinyDash memory optimization results

The first implementation includes Settings window release, result selection before icon copying, and icons loaded on demand. The functional tests pass. The fresh-process memory comparison is still in progress. No final memory saving is claimed in this version of the report.

The work follows the [optimization plan](memory-optimization-plan.md). The base commit is `568972bbc92df37f2bbfd2951e8ab478b061e205`. The baseline also includes the uncommitted files that were present before this work. This baseline differs from the build in the original 163.1 MiB screenshot.

| Change | Resulting behavior | Direct evidence |
| --- | --- | --- |
| P1, Settings | Rust retains one editing session. Settings closes only after state capture and shortcut cleanup succeed. | Twenty varied native cycles preserve input through actual window destruction. |
| P2, result construction | Search selects results before it copies their icon data. The Settings catalog uses metadata only. | The frozen search fixture matches. A separate counter measures eliminated copies. |
| P3a, icon demand | Search returns icon identifiers. Visible results request images through a bounded cache. | Native checks cover cold requests, warm requests, delayed images, and image size. This data-URL variant is only a comparison build. |
| P3b, binary icons | Tauri returns PNG bytes. The frontend creates temporary Blob URLs and releases them when no visible result needs them. | The native bridge returns `ArrayBuffer`. The browser tests cover cancellation, capacity, identity, and scale changes. This is the working implementation. |

Settings capture includes invalid and partial input, raw folder and exclusion text, the saved-settings merge base, the selected section, scroll position, and application editor state. It also includes pending import details and errors. Close does not commit the draft or write it to disk. Draft recovery across app restarts is outside this change.

The close path freezes new edits and waits for an active Save or import to settle. Rust must acknowledge a consistent snapshot before the native window is destroyed. The snapshot limit is 16 MiB. A five-second deadline, failed capture, failed cleanup, or immediate reopen preserves the live editing session. A stale capture cannot close a newly opened session. Raw text no longer resets when a backend update leaves its saved value unchanged.

The native Settings checks include successful and failed Save operations, shortcut recording, capture failure, timeout, late acknowledgement, immediate reopen, appearance changes, an unapplied import preview, an imported appearance Save, external settings changes, Discard, and section and scroll restoration. A separate test build injects a native shortcut-registration failure. That injection is absent from every memory comparison build.

P2 keeps ranking, usage bonuses, pins, stable ties, and actions. The fixed corpus has 100 applications, tied scores, aliases, Unicode, a hidden application, usage data, and more than 30 pins. Seven query cases match results recorded from the original implementation. The fixture omits icon bytes but compares all other serialized result fields.

| Synthetic payload check | Original | P2 | Difference |
| --- | ---: | ---: | ---: |
| Broad search, icon copies | 99 | 30 | 69 fewer copies |
| Broad search, copied bytes | 3,244,032 | 983,040 | 2,260,992 fewer bytes |
| Settings catalog, icon copies | 100 | 0 | 100 fewer copies |
| Settings catalog, copied bytes | 3,276,800 | 0 | 3,276,800 fewer bytes |

Each synthetic icon contains 32 KiB. These counts measure copy work per operation. They do not measure retained physical footprint. The counter is test-only and is absent from performance runs.

| Icon resource | Limit | Behavior when full |
| --- | ---: | --- |
| Encoded PNG cache | 2 MiB | Evict the least recently used entries. Return an oversized image without caching it. |
| Cached entries, including misses | 256 | Evict old entries. |
| Active native loads | 2 | Queue work within the queue limit. |
| Queued unique loads | 64 | Cancel obsolete work. Keep the placeholder if capacity is still unavailable. |
| Pending consumers | 128 | Return a capacity response. |
| Frontend entries for visible icons | 64 | Retain placeholders until the row mounts again. |
| Requested pixel size | 16 to 256 | Reject unsupported sizes. |

Requests for one image share work. A query change removes consumers that no longer need the image. A late response must match the current entry. Native extraction runs outside the search lock. Search completion does not await icon loading. At display scale 2, a 36-pixel row requests a 72-pixel image, and a 64-pixel preview requests a 128-pixel image.

Catalog generation, icon source revision, and requested size define the cache identity. Catalog refresh invalidates old images and requests. Unit tests check the byte, entry, active-job, queue, and consumer limits. They also check missing images, oversized images, cancellation, invalidation, and panic cleanup. Native tests check PNG dimensions, distinct application images, Finder custom icons, and custom icon replacement on a temporary directory.

The implementation uses Tauri's existing binary command response. It does not add a custom image URL route. The content policy adds `blob:` to `img-src`. Icon commands accept only identifiers from the application catalog. Platforms without native icon support keep their existing fallback. Native desktop validation in this report is limited to macOS.

The Rust cache limit applies to encoded image data. It does not cap decoded WebKit images or macOS framework caches. The frontend keeps no persistent image cache. It revokes each Blob URL when the last visible consumer leaves or the launcher hides.

| Validation | Result |
| --- | --- |
| Full Rust suite | 163 passed, 0 failed, 3 ignored |
| Full Playwright suite | 137 passed |
| Type checking and production frontend build | Passed |
| Native icon test, run separately | Passed |
| Twenty varied native Settings cycles | Passed |
| Native delayed-icon checks for both delivery formats | Passed |
| Native keyboard use and warm reopening, screenshots and recording | Passed |

The release benchmark uses an isolated app identifier and data directory. It does not replace the installed TinyDash app. Clipboard capture reads synthetic text through a diagnostic hook. It does not read or change the system clipboard.

Physical footprint is the primary metric. Each sample includes the host and every helper assigned to that app by macOS process responsibility. RSS is recorded separately. Each state has a 30-second settling period and 31 samples at one-second intervals. A background sampler records workload peaks. Short allocations can occur between samples, so these are sampled peaks.

The comparison uses five fresh launches per configuration. It alternates build order and preserves individual results, process membership, executable hashes, application corpus, environment records, and failed setup attempts. The controlled profile disables file roots, clipboard capture, and currency updates. The daily profile adds 50,000 files, file watching, 100 clipboard entries, pins, and cached currency data.

Native query and warm-reopen measurements disable response tracing. Their result-ready checks use accessibility data. A separate screen recording confirms visible content and working input. These checks do not measure the exact time at which pixels reach the display.

The minimal-page comparison uses the same release binary, startup services, app catalog, native icon work, and backend requests. It verifies the completed page URL and marker. The minimal page receives and discards complete responses. The measured difference describes page-related cost under that workload. It does not establish removable memory or a universal WebKit minimum.

P4 will use the repeated-use diagnostic to decide whether another frontend change is justified. Main-window release remains off. This implementation does not change the UI toolkit or establish a 50 MiB product target.
