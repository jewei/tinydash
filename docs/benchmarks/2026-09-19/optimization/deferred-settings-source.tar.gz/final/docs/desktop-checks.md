# Desktop checks

Use a Windows or Linux desktop session in a virtual machine or on a physical computer. Check Linux X11 and Wayland in separate sessions. Use the macOS application for the same checks on a Mac.

## Get the build

Open the GitHub Actions **Checks** run for the commit under test. Download the `TinyDash-<OS>-<architecture>` artifact. Check `build.txt` to confirm the commit and CPU architecture. Extract the artifact before starting the app.

Use the [installation guide](install.md) to verify checksums and install the DMG, Windows setup executable, or Ubuntu 24.04 Debian package. The Checks workflow supplies unsigned development builds. For a release candidate, use the Release workflow artifacts. Confirm the distribution and publisher-signing fields in `build.txt`. Mac candidates require Developer ID signing and notarization. Windows candidates are unsigned previews with separate updater signatures. Ubuntu uses checksums and manual updates. Windows needs the WebView2 Runtime. The Linux package needs compatible GTK 3, WebKitGTK 4.1, AppIndicator, libxdo, and OpenSSL libraries. Bun and Rust are not needed to run the build.

Quit any older TinyDash process through its tray menu before opening the new build. Reopening the window of an existing process does not load the new code.

Start the installed app from Applications on macOS, the Start menu on Windows, or the application menu on Linux. For standalone checks, use the inner Mac ZIP, the Windows executable without `-setup` in its name, or the Linux tar archive.

CI checks installation, same-version replacement, and removal. On a physical desktop, also check replacement while the app is running, the Windows WebView2 download on a clean system, and the OS response to an unsigned build. Confirm that removal preserves saved settings and history unless you explicitly request their deletion.

## Check the launcher

1. Start TinyDash. Confirm that the window appears and typing immediately enters text in the search field.
2. Search for an installed app by name. Search again with an abbreviation and part of its path. Confirm that the expected app appears.
3. Use the arrow keys. Confirm that selection moves and wraps at both ends. Press Enter and confirm that the selected app starts.
4. Press Control + Shift + Space while another app has focus. Confirm that TinyDash appears and immediately accepts text. Confirm that Siri, Spotlight, or another system panel does not open. Repeat ten times.
5. Type in a browser or terminal, then open TinyDash with the shortcut. Press Escape without entering a query. Confirm that the palette hides and you can continue typing in the same window without a click. Repeat after copying a calculation result and after closing the palette with the shortcut. Alternate between two apps to check that each opening remembers the current app.
6. Click another app. Confirm that TinyDash hides with the default `hideOnBlur` setting.
7. Use the tray menu to open the launcher and refresh the app list. Confirm that the tray can quit TinyDash.
8. Start TinyDash again while it is running. Confirm that the existing window appears and a second launcher process does not remain running.
9. Use Command/Ctrl + Enter on an app result. Confirm that the OS file manager shows its location.
10. Set `clearQueryOnOpen` to `false` in `settings.json`, restart, and reopen after a search in Emoji mode. Confirm that the query and mode remain and the query text is selected. Restore the setting after the check. Confirm that reopening then clears the query and selects the first visible category (All by default).
11. Drag the handle above the search field. Confirm that the window moves and typing still enters text in the search field. Select text with the mouse and change the search mode. Confirm that these controls do not move the window. Hide and reopen the launcher. Confirm that it keeps a position that fits on the screen.
12. Move the launcher to another display, then disconnect that display or reduce its resolution. Reopen the launcher. Confirm that it moves inside the remaining screen's work area. Check displays with different scale factors. On Wayland, check placement through the compositor because TinyDash cannot set absolute positions there.
13. Move the selection with the arrow keys while refreshing the file or application index. Confirm that the refresh keeps the latest selection if that result still exists. Enter a new query and confirm that it selects the first result.
14. Type a query, then immediately press Escape. Add a file in a configured folder while TinyDash is hidden. Reopen TinyDash and confirm that the new file is searchable. Repeat after hiding through the global shortcut and after opening a result.
15. With the default categories shown, press Tab in the search field. Confirm that Apps is selected immediately. Type a query, then press Tab again. Confirm that Files is selected, the query stays unchanged, and the search field keeps focus. Use Shift + Tab to move back. Check that selection wraps between the first and last visible categories. Make the window narrow and confirm that the bar scrolls to show the selected category. Press Escape once to hide the launcher.
16. Enable a Japanese, Chinese, or Korean input method. Start a composition in the search field, accept it, and cancel one composition with Escape. Confirm that the candidate window stays with the search field and that Escape hides TinyDash only after the composition is cancelled. Record the input method and OS.
17. Repeat the shortcut, typing, Tab, Shift + Tab, and Escape checks with a non-US keyboard layout. Check both a physical key combination and the displayed shortcut. Confirm that the shortcut opens TinyDash and that punctuation and composed characters enter the expected text.

The default global shortcut uses Control on all platforms. For shortcuts shown as Command/Ctrl, use Ctrl on Windows and Linux, and Command on macOS. If a shortcut conflicts with another application, change it in Settings and repeat the check. On macOS 27, Command + Shift + Space opens Siri Visual Intelligence and must not be used as TinyDash's default.

On macOS, run `swift tests/native/focus-macos.swift` with the built app open and Accessibility access enabled for the test process. The check opens two test windows and verifies that typing resumes in the correct window after Escape, the global shortcut, a second launch, and copying a calculation. It restores the clipboard when finished. If your shortcut uses different modifiers with Space, set `TINYDASH_TEST_SHORTCUT`, for example `TINYDASH_TEST_SHORTCUT=Super+Space swift tests/native/focus-macos.swift`.

## Check Settings

1. Open Settings with Command/Ctrl + comma. Close it, then open it from the Actions menu and the tray menu. Confirm that there is one Settings window.
2. Select **Record new**. Press a key combination, then **Save changes**. Use that combination while another app has focus. Confirm that TinyDash opens without a restart. Restore the original shortcut after this check.
3. Cancel a recording with Escape. Confirm that the saved shortcut still works. Try a shortcut already used by another app. If the OS rejects it, confirm that the error appears and the previous shortcut still works.
4. Change **Hide when focus is lost** and **Clear search when opened**. Save, then check each behaviour. Confirm that Settings stays open when another app has focus.
5. Choose Light, Dark, and Compact in Appearance. Confirm that the launcher changes immediately and keeps the choice after a restart.
6. In a separate test profile, change the clipboard limit and file folders. Save and confirm that the history limit and file index update without a restart. Turn currency updates off and confirm that saved rates remain usable.
7. Change a field without saving, close Settings, and reopen it. Confirm that the edit remains. Select **Discard** and confirm that the saved value returns.
8. Close Settings with its window close control, Escape, and the launcher shortcut. Confirm that TinyDash stays running, the launcher can reopen, and only one Settings window exists after reopening. Repeat while another app has focus.
9. Open **Categories**. Clear some checkboxes, including the active category, then select **Save changes**. Confirm that the bar shows only the selected categories and selects the first visible one. Check that Tab and Shift + Tab skip hidden categories. Keep only one checkbox selected and confirm that you cannot clear it. Restart TinyDash and confirm that the choices remain saved. Restore the original category choices after this check.
10. In **Search**, add an app alias with accented, Chinese, or Japanese text. Save and search by that alias. Remove it and confirm that its matches disappear. Hide the app, refresh applications, and restart. Confirm that it stays hidden. Restore it in Settings. Check a weak alias against another app's exact name.
11. Record a category shortcut. Save and use it while another app has focus. Confirm that it opens an empty search in that category. Remove the binding, save, and confirm that it stops working. Test a conflict without losing the previous binding. On Wayland, use a desktop shortcut for `tinydash --mode clipboard`. Test the command with both a stopped and a running TinyDash process.
12. Turn on **Start at login**, save, and sign out and in. Confirm that one TinyDash process starts and the launcher stays hidden. Turn it off, save, and repeat. Confirm that TinyDash does not start.
13. Export saved settings through **Privacy**. Preview the file through import. Cancel and confirm that nothing changes. Import again, apply the preview, and confirm that settings stay unchanged until **Save changes**. Check invalid JSON, unsupported versions, unknown keys, and file paths from another operating system. An invalid import must leave saved settings unchanged.
14. In **About**, check for updates in a development build. Confirm that it gives package instructions. Use release candidate packages and the separate test feed for the update, failed-download, signature, and recovery checks in [release verification](release-verification.md). Windows previews have updater signatures but no publisher signature. Preserve the source files before manual recovery.

## Check passwords, time zones, URLs, and web search

Use generated test values for these checks. Restore the original clipboard when finished.

1. Enter `password 32`. Confirm that the results include symbols, letters and digits, a word passphrase, and a PIN. Check the strength estimate. Copy the first result and confirm that it matches the displayed 32 characters. Confirm that this copy does not appear in TinyDash's clipboard history.
2. Check `password letters 64`, `passphrase 6`, and `pin 6`. Confirm the character, word, or digit count. Check that `password 5` and `password 65` show an error. Select **Generate another** and confirm that the selected type stays selected. Clear the query, enter it again, and confirm that new passwords appear.
3. Enter `time in tokyo` and `time in us`. Check the named zones, dates, and UTC offsets. Leave the current time visible across a minute change and confirm that it updates.
4. Enter `tomorrow 3pm london`. Confirm that the source date is tomorrow in London and the local result has the correct date and offset. Check `2026-03-29 1:30 london` for a missing-time error and `2026-10-25 1:30 london` for two possible results.
   In **Datetime**, enter `next friday + 2 week`. Confirm that the result is two weeks after the next Friday and uses your local date. Copy it and check the `YYYY-MM-DD` value. Enter `10:00 a.m. Pacific Time` and confirm that the source date, source offset, local date, and local offset appear. Compare `2026-09-17 10:00 a.m. Pacific Time` with `2026-12-15 10:00 a.m. Pacific Time` to check both daylight saving and standard time.
5. Paste `https://www.youtube.com/watch?v=demo&t=90&si=test&utm_source=share`. Confirm that two fields are removed and `v` and `t` remain. Copy the result and check the exact URL. Repeat with an Amazon product URL containing `tag` and a Spotify URL containing `si`.
6. Use **Open cleaned URL** with a known public page. Confirm that the default browser opens the cleaned address.
7. Enter `web rust & c++`. Confirm that Google, DuckDuckGo, Bing, Brave, YouTube, and GitHub appear. Copy each search URL and confirm that the complete query is one parameter. Open a search and confirm that the chosen engine receives that text. Check `ddg rust`, `yt rust`, and `gh rust` for one-engine searches. In All mode, enter `gh`, `brave`, or `google` without search text. Confirm that matching installed apps appear without an empty web search warning. With Ghostty installed, check that `gh` finds it and `gh rust` still searches GitHub.
8. In **Settings > Search**, add a web search with keyword `docs` and template `https://example.com/search?q={query}`. Preview spaces, Unicode, `&`, `+`, and trailing newlines. Save and search `docs rust & c++`. Copy the URL and confirm that the query remains one value. Pin the result, reorder templates, and confirm that the pin still uses the same keyword. Disable or remove the template and confirm that it cannot run through the pin.
9. Check `September 18 2026`, `18 September`, `3pm SGT to London`, and `time in Tokyo to London`. Confirm the dates and target-zone labels. Check an invalid date and an unknown source or target zone. TinyDash must report an error instead of using an unrelated zone.

Password generation, time conversion, and URL cleaning must also work with the network disconnected. Web searches need a connection only after opening them in the browser.

## Check calculations and emoji

1. In All mode, enter `12 * 8`. Confirm that `96` is the first result. Press Enter, then paste into a text editor. Confirm that the pasted text is `96`.
2. Select Calculator mode. Check `sqrt(144)` → `12`, `5 ft to cm` → `152.4 cm`, and `32 C to F` → `89.6 °F`. Confirm that unit conversion also works with the network disconnected.
3. Enter `12 +` in Calculator mode. Confirm that an error appears and no copy action is available. Enter `12 + 1` and confirm that the error clears.
4. In All mode, enter `:rocket`. Confirm that 🚀 is the first result. Press Enter, then paste into a text editor. Confirm that the complete emoji is pasted.
5. Search for `coffee`, `laugh`, and `heart` in Emoji mode. Check the results and the copy action. Use Command/Ctrl + K to confirm that the actions menu offers Copy and no app-location action.
6. Change between Apps, Emoji, and Calculator modes while a query is present. Confirm that results follow the selected mode. Reopen TinyDash after each copy and confirm that the input accepts text.

7. While online, enter `100 USD to MYR` in Calculator mode. Confirm that the result includes the ECB rate date. Use Command/Ctrl + R to refresh and confirm that typing remains responsive.
8. After a successful refresh, disconnect the network and restart TinyDash. Confirm that currency conversion still works from SQLite. Refresh again and confirm that the error does not remove the saved result. Arithmetic and units must also work without any saved rates.
9. Set `currencyRatesEnabled` to `false` and restart. Confirm that saved rates remain usable and a manual refresh reports the disabled setting. Restore the setting after the check.
10. With saved rates, compare `10 USD CAD` and `10 USD to CAD`. Confirm that both give the same value and rate date. Confirm that ordinary unit conversions still work.

Clipboard access and emoji fonts can differ across desktop sessions; record any failure with the session details. Automatic paste is not implemented.

## Check usage ranking

Select an app and pin it from its detail panel. Clear the query in All or Apps and confirm that the app appears in the Pinned group. Restart TinyDash and confirm that the pin remains. Search for another app by its exact name and confirm that the pin does not change the match order. Switch to Compact, unpin the app through Actions, and confirm that the Pinned group disappears when no pins remain. Restore the original pins after this check.

1. Launch an app from a lower position in the list. Reopen TinyDash and clear the query. Confirm that the app moves higher in the list.
2. Copy an emoji. Reopen TinyDash and enter `:`. Confirm that the copied emoji moves higher in the emoji list.
3. Quit TinyDash fully, then start it again. Confirm that both ranking changes remain. Reopening a hidden window is not a process restart.
4. Search for an exact app name after using another app several times. Confirm that the exact match remains above weak matches.
5. Set `clearQueryOnOpen` to `false`, restart, and launch an app from a query with several matches. Reopen the launcher. Confirm that it keeps the query and refreshes the order. Restore the setting after the check.

The existing usage history can affect the order. Use a separate test profile for repeatable checks. Usage records do not contain queries or calculation text.

## Check clipboard history

Use test text for these checks. History stores text without encryption. These checks delete saved history, so use a separate test profile.

On a fresh profile, copy text before choosing a history setting. Confirm that TinyDash captures nothing. Choose **Keep history off** and restart. Confirm that capture stays off. Enable history in Settings before the following checks. Repeat with a fresh profile and **Enable history**. Confirm that the choice survives a restart.

1. Copy a short text with several lines, spaces, and an emoji from a text editor. Open TinyDash and select Clipboard. Confirm that the entry appears within two seconds and the preview preserves its text.
2. Copy the same text twice. Confirm that only one entry exists. Copy different text, then the first text again. Confirm that the first entry moves to the top.
3. Search for a word from the second line. Confirm that both Clipboard mode and All mode find the entry. Confirm that Apps mode does not return clipboard text.
4. Copy another value in the editor. Select the older entry in TinyDash and press Enter. Paste into the editor. Confirm that the full historical text is restored.
5. Delete that entry with Command/Ctrl + Backspace. Confirm that the launcher stays open. Reopen it and confirm that the unchanged clipboard does not restore the deleted entry during this session.
6. Select **Actions > Clear all clipboard history**. Confirm that Cancel receives focus. Cancel first and confirm that entries remain. Then confirm the clear action and check that all entries disappear. Confirm that the current system clipboard is unchanged.
7. Capture new test text, quit TinyDash fully, then start it again. Confirm that saved entries remain. Startup also captures the current system clipboard.
8. Set `clipboardHistoryLimit` to 2 and restart. Copy three distinct values at least two seconds apart. Confirm that only the newest two remain. Restore the setting to 100.
9. Set `clipboardHistoryEnabled` to `false` and restart. Copy new text and confirm that no new entry appears. Confirm that existing entries can still be copied and cleared. Restore the setting when finished.
10. Copy an image, whitespace-only text, and text larger than 16 KiB. Confirm that none becomes an entry. Test clipboard capture while the launcher is hidden and after reopening it.
11. Create an older pinned entry and then copy a newer unpinned entry. Open Clipboard with an empty query. Confirm that both entries appear, pins keep their visual group, and the selected entry is the newest copied entry. Record the selected entry if the pinned entry receives focus instead.
12. Pin one entry in All and another in Clipboard. Keep two unpinned entries. Use **Actions > Clear unpinned history** and restart. Confirm that both pins remain and the unpinned entries are gone. Use **Clear all clipboard history**, restart, and confirm that all entries and their pins are gone. Before each restart, copy whitespace-only text in another app so startup capture cannot add the previous clipboard value again.
13. Use **Edit a copy** on multiline text with spaces and Unicode. Copy the edit into a text editor. Confirm that the exact edit was copied and the original history entry is unchanged. Test cancellation and an edit over 16,384 bytes. The error must keep the dialog open without changing the clipboard.
14. Use **Copy selected entries**. Select entries in a different order from the list. Check each separator and compare the pasted output. Test a combined value over 16,384 bytes. Use **Save text as a file**, cancel once, then save. Confirm that the file contains the full original text and that neither action changes the history entries.

macOS and Windows read their clipboard change counters once per second. Copies made within the same interval can be missed. Linux uses GTK clipboard events. On Wayland, the compositor can limit access while TinyDash lacks focus; record which changes appear only after opening the launcher.

## Check file search

1. Put a text file in Documents. Give it a name with spaces and Unicode characters. Restart TinyDash, select Files, and wait for the scan to finish.
2. Search by filename, abbreviation, and part of the full path. Confirm that All mode also finds the file. Confirm that Apps mode does not return it.
3. Search for text that occurs only inside the file. Confirm that the file does not appear.
4. Press Enter on the file. Confirm that its default application opens it. Reopen TinyDash and use Command/Ctrl + Enter to show it in the file manager.
5. Add and rename a second file. Confirm that the results update without a manual refresh. Create a new subfolder and immediately add a file inside it. Confirm that the file appears.
6. Delete the first file outside TinyDash. Confirm that its result disappears automatically. If an old result is opened before the scan finishes, confirm that the app reports that the file is unavailable.
7. Rename a configured root folder, then recreate it and add a file. Confirm that the replacement root updates. Use Refresh files to confirm that manual recovery remains available. Set `fileWatchEnabled` to `false` and restart to check manual-only operation, then restore the setting.
8. Configure a temporary folder in `fileSearchRoots`. Add hidden files, an excluded `node_modules` folder, and symbolic links. Restart and confirm that the scanner excludes them. Test a folder without read permission and confirm that the app stays usable and shows a warning.
9. Set `fileSearchLimit` to 2 in a folder with three files. Restart and confirm that the UI reports an incomplete scan. Set `fileSearchRoots` to `[]`, restart, and confirm that Files mode is empty. Restore the settings when finished.
10. In Settings, select only `~/Documents` and save. Confirm that a known Documents file appears. Change the folder to `~/Downloads` and save without restarting. Confirm that the Documents result disappears immediately and only Downloads files appear after the scan. Repeat while a scan is in progress, then turn file search off and confirm that the results stay empty.

File access depends on OS permissions. On macOS, record any Files and Folders permission prompt or denial. Test Windows redirected Known Folders and Linux XDG user directories if available. Files open through their OS association; a missing or broken association can prevent the target application from opening.

## Check system commands

1. Select System. Confirm that the supported commands appear. Search `reboot`, `suspend`, and `preferences`. Confirm that the aliases find Restart, Sleep, and Open system settings. Check the same queries in All mode and confirm that Apps mode excludes system commands.
2. Select Restart and press Enter. Confirm that the dialog names Restart and Cancel has focus. Press Enter again. Confirm that the dialog closes and the computer remains running.
3. Select Shut down with its numbered shortcut. Press Escape in the dialog. Confirm that the launcher stays open and no command runs. Repeat through the actions menu.
4. Open a power confirmation dialog, hide the launcher by clicking another app, then reopen it. Confirm that the old confirmation is gone.
5. Run Open system settings. Confirm that the correct settings app opens. Reopen TinyDash and confirm that the command's usage ranking has changed.
6. In a disposable desktop session, save work and test Lock screen if offered. Unlock and confirm that TinyDash can open again. On macOS without the legacy `CGSession` helper, the command is omitted; use Control + Command + Q.
7. In a disposable desktop session, save work and confirm Sleep, Restart, and Shut down separately. Check the OS transition. Do not run these checks on a hosted CI runner or a computer with active work.
8. On Linux, test the desktop's policy denial or a missing service. Confirm that TinyDash reports the failure and remains usable. Check X11 and Wayland separately. A standalone compositor must provide a supported screen-lock service for Lock screen to work.

Automated tests cover command search, confirmation, cancellation, and backend rejection of requests without confirmation. They do not prove that a power transition completes. Mark transitions that were not run as pending. An OS can accept a request and then cancel it because of unsaved work or session policy.

## Linux session differences

- On X11, test the registered global shortcut directly.
- On Wayland, TinyDash displays a shortcut warning. Assign a desktop or compositor shortcut to the TinyDash executable, then test opening the existing window and input focus. Direct global shortcut registration is not supported in this version.
- Record the desktop environment and whether a tray extension is installed. If the tray is unavailable, test access through the taskbar or by starting the executable again.

The native CI tests use a virtual X11 display. They do not establish Wayland support, reliable global shortcuts, or correct focus behavior on every desktop.

## Record the result

Include the following information in the issue or pull request:

```text
Commit:
OS version and CPU architecture:
Desktop environment and X11/Wayland session, if applicable:
Checks passed:
Checks failed or not run:
Steps to reproduce a failure:
Screenshot or log:
```

Mark checks that were not run as pending. A successful build alone does not verify desktop behavior.
