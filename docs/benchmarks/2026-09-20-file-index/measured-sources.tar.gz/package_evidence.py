"""Archive the completed measurement inputs and raw observations for review."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/jewei/Dev/tinydash-file-index-perf')
OUT=REPO/'docs/benchmarks/2026-09-20-file-index'
OUT.mkdir(parents=True,exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(path,files):
    assert not path.exists(), f'Refusing to replace {path}'
    with tarfile.open(path,'w:gz',compresslevel=6) as tar:
        for source,name in files:
            tar.add(source,arcname=name,recursive=False)


assert (ROOT/'native-summary.json').exists()
assert len(list((ROOT/'results/native').glob('*.json')))==20
original=Path('/Users/jewei/Downloads/tinydash-performance-review-9vj0b3av')
raw=[]
for directory,prefix in [(ROOT/'results','native'),(ROOT/'provider/results','provider'),
                         (original/'results','initial-review'),(original/'bundle/benchmark/results','supplied-linux')]:
    raw.extend((p,str(Path(prefix)/p.relative_to(directory))) for p in sorted(directory.rglob('*.json')))
raw.extend((ROOT/name,name) for name in ['builds.json','native-plan.json','native-summary.json','ci-pr-run.json','ci-push-run.json'])
raw.extend((ROOT/'provider'/name,str(Path('provider')/name)) for name in ['manifest.json','summary.json','environment-before.json'])
raw.extend((original/name,str(Path('initial-review')/name)) for name in ['manifest.json','checks.json','REVIEW.md'])
raw.extend((original/'bundle'/name,str(Path('supplied-linux')/name)) for name in ['README.md','source-manifest.json','bundle-sha256.json'])
raw.extend((p,str(Path('logs')/p.relative_to(ROOT/'logs'))) for p in sorted((ROOT/'logs').glob('*.log')))
raw.extend((p,str(Path('ci-linux-first-failure')/p.relative_to(ROOT/'ci-linux-failure'))) for p in sorted((ROOT/'ci-linux-failure').glob('*')) if p.is_file())
archive(OUT/'raw-results.tar.gz',raw)

sources=[]
tracked=subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only','06974f411483f5d254d80b617d9fcbe4dc114a71'],text=True).splitlines()
base_archive=subprocess.check_output(['git','-C',str(REPO),'archive','06974f411483f5d254d80b617d9fcbe4dc114a71'])
with tarfile.open(fileobj=io.BytesIO(base_archive)) as tar:
    base_files={member.name:tar.extractfile(member).read() for member in tar.getmembers() if member.isfile()}
for variant in ['baseline','candidate']:
    source=ROOT/variant
    for relative in tracked+['src-tauri/src/memory_probe.rs','src/memory-hooks.ts','src/memory-minimal.ts','minimal.html']:
        path=source/relative
        if path.is_file() and path.read_bytes()!=base_files.get(relative):
            sources.append((path,str(Path('overlays')/variant/relative)))
for relative in ['scripts/perf/memory/run.py','scripts/perf/memory/prepare.py','scripts/perf/memory/probe.rs',
                 'scripts/perf/memory/memory-hooks.ts','scripts/perf/memory/minimal.ts',
                 'docs/benchmarks/2026-09-19/measure.py','docs/benchmarks/2026-09-19/ui.swift']:
    sources.append((ROOT/'tools'/relative,str(Path('tools')/relative)))
for relative in ['native.py','clipboard.swift','summarize_native.py','package_evidence.py','provider/reproduce.py']:
    sources.append((ROOT/relative,relative))
archive(OUT/'measured-sources.tar.gz',sources)

summary=json.loads((ROOT/'native-summary.json').read_text())
(OUT/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'provider-summary.json').write_bytes((ROOT/'provider/summary.json').read_bytes())
manifest={
    'baseline_commit':'06974f411483f5d254d80b617d9fcbe4dc114a71',
    'candidate_product_commit':'7784a47861a8db68ab5cfded9c431452111f8fc9',
    'host':{'cpu':'Apple M2','os':'macOS 27.0','architecture':'arm64','rust':'1.98.1'},
    'native_builds':json.loads((ROOT/'builds.json').read_text()),
    'helper_executable_sha256':{name:digest(ROOT/name) for name in ['control/ui','clipboard']},
    'measurement_script_sha256':{name:digest(ROOT/name) for name in ['native.py','summarize_native.py','provider/reproduce.py']},
    'files_sha256':{p.name:digest(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='manifest.json'},
    'raw_record_sha256':{name:digest(p) for p,name in raw},
    'limits':['The native builds contain the same isolated diagnostic overlay.',
              'Raw smoke fields named without_clipboard_write assert unchanged text, not a write counter.',
              'The first local timing run is inconclusive and remains in the archive.',
              'The Linux source bundle did not contain its benchmark executables.'],
}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(OUT)
for p in sorted(OUT.iterdir()):print(p.name,p.stat().st_size)
