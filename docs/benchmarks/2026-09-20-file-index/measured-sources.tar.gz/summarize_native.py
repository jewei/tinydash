"""Summarize all planned launches. Preserve failures and use paired resampling."""
from collections import defaultdict
import json
import math
from pathlib import Path
import random
import statistics

ROOT=Path(__file__).resolve().parent
paths=sorted((ROOT/'results/native').glob('*.json'))
records=[json.loads(p.read_text()) for p in paths]
assert len(records)==20, f'Expected 20 runs; found {len(records)}'
assert not any('error' in r for r in records), 'A native run failed'
assert all(not r['remaining_helpers'] for r in records), 'A helper remained after exit'
by_key={(r['profile'],r['pair'],r['variant']):r for r in records}
assert len(by_key)==20
builds=json.loads((ROOT/'builds.json').read_text())
for run in records:
    assert run['catalog']==records[0]['catalog'], 'Application corpus changed between launches'
    assert run['executable_sha256']==builds[run['variant']]['executable_sha256']
    expected_ipc={('saf','apps'),('term','apps'),('12 * 8','calculator')}
    expected_ui={('Apps','saf'),('Calculator','12 * 8')}
    if run['profile']=='daily':
        expected_ipc|={('document','files'),('café','files'),('folder-072','files'),('memory fixture','clipboard')}
        expected_ui|={('Files','document-001'),('Files','café-document-010')}
    for kind in ['ipc_queries','sustained_queries','ui_queries']:
        expected=expected_ui if kind=='ui_queries' else expected_ipc
        count=15 if kind=='ui_queries' else 25
        groups_for_run=defaultdict(list)
        for row in run[kind]:
            key=(row['category'],row['query']) if kind=='ui_queries' else (row['query'],row['mode'])
            groups_for_run[key].append(row['round'])
            assert math.isfinite(row['ms']) and row['ms']>=0
        assert set(groups_for_run)==expected, f'Missing or extra cases in {kind}'
        for rounds in groups_for_run.values():
            assert sorted(rounds)==list(range(-2,count)), f'Missing or repeated samples in {kind}'
    assert sorted(row['iteration'] for row in run['reopen']['samples'] if not row['warmup'])==list(range(20))
    assert all(math.isfinite(row['ms']) and row['ms']>=0 and row['success'] for row in run['reopen']['samples'])
for profile in ['controlled','daily']:
    for pair in range(1,6):
        before=by_key[profile,pair,'baseline']
        after=by_key[profile,pair,'candidate']
        assert before['catalog']==after['catalog'], f'Application corpus changed: {profile}, {pair}'
        for key in ['ipc_queries','sustained_queries']:
            expected=[(r['query'],r['mode'],r['round'],r['results']) for r in before[key]]
            actual=[(r['query'],r['mode'],r['round'],r['results']) for r in after[key]]
            assert expected==actual, f'Result difference: {profile}, {pair}, {key}'
        expected=[(r['category'],r['query'],r['round'],r['titles']) for r in before['ui_queries']]
        actual=[(r['category'],r['query'],r['round'],r['titles']) for r in after['ui_queries']]
        assert expected==actual, f'UI result difference: {profile}, {pair}'


def percentile(values,fraction):
    ordered=sorted(values)
    return ordered[max(0,math.ceil(len(ordered)*fraction)-1)]


def paired_interval(before,after):
    differences=[b-a for a,b in zip(before,after,strict=True)]
    rng=random.Random(20260920)
    means=[]
    for _ in range(10000):
        means.append(statistics.mean(rng.choices(differences,k=len(differences))))
    return {
        'baseline':before,'candidate':after,'paired_differences':differences,
        'baseline_mean':statistics.mean(before),'candidate_mean':statistics.mean(after),
        'mean_difference':statistics.mean(differences),
        'bootstrap_mean_difference_95_percent':[percentile(means,.025),percentile(means,.975)],
    }


groups=defaultdict(dict)
for run in records:
    values=defaultdict(list)
    for kind in ['ipc_queries','sustained_queries','ui_queries']:
        for sample in run[kind]:
            if sample['round']<0:continue
            key=(kind,sample.get('mode',sample.get('category')),sample['query'])
            values[key].append(sample['ms'])
    for sample in run['reopen']['samples']:
        assert sample['success']
        if not sample['warmup']:values['reopen','all',''].append(sample['ms'])
    for key,samples in values.items():
        for name,fraction in [('p50',.5),('p95',.95)]:
            groups[(run['profile'],*key,name)][run['pair'],run['variant']]=percentile(samples,fraction)

latencies=[]
for key,values in sorted(groups.items()):
    profile,kind,mode,query,percentile_name=key
    before=[values[pair,'baseline'] for pair in range(1,6)]
    after=[values[pair,'candidate'] for pair in range(1,6)]
    comparison=paired_interval(before,after)
    margin=max(2,comparison['baseline_mean']*.05) if percentile_name=='p50' else max(5,comparison['baseline_mean']*.10)
    low,high=comparison['bootstrap_mean_difference_95_percent']
    status='pass' if high<=margin else ('fail' if low>margin else 'inconclusive')
    latencies.append({'profile':profile,'kind':kind,'mode':mode,'query':query,
                      'percentile':percentile_name,'margin_ms':margin,'status':status,**comparison})

assert len(latencies)==56, f'Expected 56 latency comparisons; found {len(latencies)}'
memory=[]
for profile in ['controlled','daily']:
    for stage in ['startup_hidden','first_use_hidden','settings_hidden','sustained_hidden','visible_after_first_use']:
        variants={}
        for variant in ['baseline','candidate']:
            values=[]
            for pair in range(1,6):
                run=by_key[profile,pair,variant]
                if stage=='visible_after_first_use':
                    value=sum(p['footprint_bytes'] for p in run[stage]['processes'])
                else:
                    assert len(run[stage]['samples'])==5
                    value=run[stage]['median_footprint_bytes']
                values.append(value/2**20)
            variants[variant]=values
        memory.append({'profile':profile,'stage':stage,'unit':'MiB',**paired_interval(variants['baseline'],variants['candidate'])})

result={
    'runs':len(records),'result_equivalence':True,'application_corpus_equivalence':True,
    'remaining_helpers_after_exit':False,'bootstrap_resamples':10000,'seed':20260920,
    'latency_pass':all(row['status']=='pass' for row in latencies),
    'latency_comparisons':latencies,'memory_comparisons':memory,
    'limits':['Five launch pairs give limited precision. Bootstrap intervals describe the paired mean differences.',
              'No claim of whole-application memory saving follows from provider allocation counts.',
              'Webview event timings include IPC and DOM updates, but do not measure pixels reaching the display.',
              'The daily-use workload is a synthetic repeatable profile, not a human usage trial.'],
}
(ROOT/'native-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('Runs:',len(records),'Latency pass:',result['latency_pass'])
for row in latencies:
    if row['status']!='pass':
        print(row['status'],row['profile'],row['kind'],row['mode'],row['query'],row['percentile'],row['bootstrap_mean_difference_95_percent'],'margin',row['margin_ms'])
for row in memory:
    print(row['profile'],row['stage'],'before/after MiB',round(row['baseline_mean'],2),round(row['candidate_mean'],2),'difference 95%',row['bootstrap_mean_difference_95_percent'])
