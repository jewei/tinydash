"""Reproduce the supplied provider benchmarks without changing project sources."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess


parser = argparse.ArgumentParser()
parser.add_argument("phase", choices=["build", "measure", "summarize"])
parser.add_argument("--bundle", required=True, type=Path)
parser.add_argument("--baseline", required=True, type=Path)
parser.add_argument("--candidate", required=True, type=Path)
parser.add_argument("--scratch", required=True, type=Path)
args = parser.parse_args()
evidence = Path(__file__).resolve().parent
results = evidence / "results"
logs = evidence / "logs"
binary_dir = args.scratch / "bin"
target_dir = args.scratch / "benchmark-target"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_case(variant, mode, corpus, block=None):
    command = [str(binary_dir / f"{variant}-{mode}"), corpus]
    suffix = f"-{block}" if block is not None else ""
    if mode == "timing":
        command += ["100", "50000"]
    output = subprocess.check_output(command)
    json.loads(output)
    path = results / f"{variant}-{corpus}-{mode}{suffix}.json"
    path.write_bytes(output)
    print(path.name, flush=True)


if args.phase == "build":
    binary_dir.mkdir(parents=True, exist_ok=True)
    metadata = {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "rustc": subprocess.check_output(["rustc", "-Vv"], text=True),
        "baseline_commit": subprocess.check_output(
            ["git", "-C", str(args.baseline), "rev-parse", "HEAD"], text=True
        ).strip(),
        "patch_sha256": digest(args.bundle / "changes.patch"),
        "binary_sha256": {},
        "timing_order": [],
    }
    for variant, source in [("baseline", args.baseline), ("candidate", args.candidate)]:
        for mode in ["alloc", "timing"]:
            env = dict(os.environ)
            env.update(TINYDASH_SOURCE_ROOT=str(source), CARGO_TARGET_DIR=str(target_dir))
            command = ["cargo", "build", "--locked", "--release"]
            if mode == "alloc":
                command += ["--features", "track-allocations"]
            log = logs / f"build-{variant}-{mode}.log"
            print(f"Building {variant}-{mode}", flush=True)
            with log.open("w") as stream:
                completed = subprocess.run(
                    command, cwd=args.bundle / "benchmark", env=env,
                    stdout=stream, stderr=subprocess.STDOUT,
                )
            if completed.returncode:
                print(log.read_text(), flush=True)
                raise SystemExit(completed.returncode)
            binary = binary_dir / f"{variant}-{mode}"
            shutil.copy2(target_dir / "release/tinydash-file-provider-profile", binary)
            metadata["binary_sha256"][binary.name] = digest(binary)
    (evidence / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")

elif args.phase == "measure":
    for variant in ["baseline", "candidate"]:
        for corpus in ["ascii", "mixed", "clipboard", "equivalence"]:
            run_case(variant, "alloc", corpus)
    metadata = json.loads((evidence / "manifest.json").read_text())
    # Match the five alternating blocks in the supplied method. These are
    # descriptive samples, with no claim of statistical non-inferiority.
    for block in range(1, 6):
        order = ["baseline", "candidate"] if block % 2 else ["candidate", "baseline"]
        metadata["timing_order"].append(order)
        for variant in order:
            for corpus in ["ascii", "mixed"]:
                run_case(variant, "timing", corpus, block)
    metadata["result_sha256"] = {p.name: digest(p) for p in sorted(results.glob("*.json"))}
    (evidence / "manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")

else:
    def read(name):
        return json.loads((results / name).read_text())

    summary = {"files": {}, "clipboard": [], "equivalence_cases": 0}
    for corpus in ["ascii", "mixed"]:
        before = read(f"baseline-{corpus}-alloc.json")
        after = read(f"candidate-{corpus}-alloc.json")
        assert before["result_equivalence"] == after["result_equivalence"]
        timings = {
            variant: [read(f"{variant}-{corpus}-timing-{i}.json") for i in range(1, 6)]
            for variant in ["baseline", "candidate"]
        }
        for variant in timings:
            for run in timings[variant]:
                assert run["result_equivalence"] == before["result_equivalence"]
        summary["files"][corpus] = {
            "before_retained_bytes": before["index_retained_bytes"],
            "after_retained_bytes": after["index_retained_bytes"],
            "saving_percent": (1 - after["index_retained_bytes"] / before["index_retained_bytes"]) * 100,
            "before_allocations": before["index_allocations"],
            "after_allocations": after["index_allocations"],
            "before_constructor_ms": statistics.median(r["index_ns"] for r in timings["baseline"]) / 1e6,
            "after_constructor_ms": statistics.median(r["index_ns"] for r in timings["candidate"]) / 1e6,
            "search": [],
        }
        for i, row in enumerate(timings["baseline"][0]["queries"]):
            search = {"query": row["query"]}
            for variant in timings:
                for percentile in ["p50", "p95"]:
                    search[f"{variant}_{percentile}_ms"] = statistics.median(
                        r["queries"][i][f"{percentile}_ns"] for r in timings[variant]
                    ) / 1e6
            summary["files"][corpus]["search"].append(search)
    before = read("baseline-clipboard-alloc.json")["records"]
    after = read("candidate-clipboard-alloc.json")["records"]
    for b, a in zip(before, after, strict=True):
        assert b["case"] == a["case"] and b["result"] == a["result"]
        summary["clipboard"].append({
            "case": b["case"],
            "before_peak_extra_bytes": b["peak_extra_bytes"],
            "after_peak_extra_bytes": a["peak_extra_bytes"],
            "before_allocations": b["allocations"],
            "after_allocations": a["allocations"],
        })
    before = read("baseline-equivalence-alloc.json")
    after = read("candidate-equivalence-alloc.json")
    assert before == after
    summary["equivalence_cases"] = len(before["records"])
    (evidence / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
