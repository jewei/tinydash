import AppKit

let board = NSPasteboard.general
let saved = (board.pasteboardItems ?? []).map { item in
    item.types.compactMap { type -> (NSPasteboard.PasteboardType, Data)? in
        guard let data = item.data(forType: type) else { return nil }
        return (type, data)
    }
}
var ownedChange: Int? = nil
func reply(_ object: [String: Any]) {
    let data = try! JSONSerialization.data(withJSONObject: object)
    print(String(data: data, encoding: .utf8)!)
    fflush(stdout)
}
reply(["ready": true])
while let line = readLine() {
    let value = try! JSONSerialization.jsonObject(with: Data(line.utf8)) as! [String: Any]
    if value["op"] as? String == "matches" {
        let matches = board.string(forType: .string) == value["text"] as? String
        if matches { ownedChange = board.changeCount }
        reply(["matches": matches])
    } else if value["op"] as? String == "restore" {
        var restored = false
        if let count = ownedChange, count == board.changeCount {
            let items = saved.map { rows in
                let item = NSPasteboardItem()
                for (type, data) in rows { item.setData(data, forType: type) }
                return item
            }
            board.clearContents()
            if !items.isEmpty { board.writeObjects(items) }
            restored = true
        }
        reply(["restored": restored, "userChangePreserved": ownedChange != nil && !restored])
        break
    }
}
