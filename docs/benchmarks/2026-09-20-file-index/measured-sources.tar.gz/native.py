"""Native validation for the file-index patch. Run only the isolated test apps."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("memory_run", ROOT / "tools/scripts/perf/memory/run.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
r.IDENTIFIER = "dev.tinydash.fileindexperf.20260920"
r.PROFILE = Path.home() / "Library/Application Support" / r.IDENTIFIER
r.CONTROL = ROOT / "control"
r.m.BASE = r.CONTROL
FIXTURE = ROOT / "files"


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def environment():
    rows = subprocess.check_output(["ps", "-Ao", "pid,pcpu,comm"], text=True).splitlines()[1:]
    processes = []
    for row in rows:
        pid, cpu, name = row.strip().split(None, 2)
        processes.append({"pid": int(pid), "cpu_percent": float(cpu), "executable": name})
    return {"timestamp": time.time(), "load_average": os.getloadavg(),
            "cpu_sum_percent": sum(p["cpu_percent"] for p in processes),
            "top_cpu": sorted(processes, key=lambda p: p["cpu_percent"], reverse=True)[:10]}


def prepare():
    r.CONTROL.mkdir(exist_ok=True)
    if not r.PROFILE.exists():
        r.PROFILE.mkdir()
        (r.PROFILE / ".memory-benchmark-owner").write_text(r.IDENTIFIER + "\n")
    assert (r.PROFILE / ".memory-benchmark-owner").read_text().strip() == r.IDENTIFIER
    for folder in range(100):
        directory = FIXTURE / f"folder-{folder:03}"
        directory.mkdir(parents=True, exist_ok=True)
        for number in range(500):
            name = ("café-" if number % 10 == 0 else "") + f"document-{number:03}.txt"
            path = directory / name
            if not path.exists():
                path.write_text("TinyDash file index test\n")


def launch(variant, profile):
    r.reset_profile(profile == "daily", FIXTURE)
    bundle = ROOT / "apps" / variant / "TinyDashFileIndexPerf.app"
    executable = (bundle / "Contents/MacOS/tinydash").resolve()
    assert not any("TinyDashFileIndexPerf.app/Contents/MacOS/tinydash" in name
                   for name in r.m.processes().values()), "Another test app is active"
    (r.CONTROL / "control.sock").unlink(missing_ok=True)
    (r.CONTROL / "app.log").write_text("")
    subprocess.run(["open", "-n", str(bundle), "--env", f"TINYDASH_MEMORY_CONTROL={r.CONTROL}",
                    "--env", "TINYDASH_MEMORY_PAGE=real", "--env", f"TINYDASH_MEMORY_DAILY={int(profile == 'daily')}",
                    "--stdout", str(r.CONTROL / "app.log"), "--stderr", str(r.CONTROL / "app.log")], check=True)
    pid = r.until(lambda: next((pid for pid, name in r.m.processes().items() if name == str(executable)), None))
    assert r.m.LIB.responsibility_get_pid_responsible_for_pid(pid) == pid
    r.until(lambda: (s := r.command("status"))["ready"] and not s["scanning"])
    r.until(lambda: r.evaluate('return !!document.querySelector("input[role=combobox]");'))
    expected = 50000 if profile == "daily" else 0
    r.until(lambda: r.evaluate(f'const r=await window.__memoryBackend.search("","files"); return !r.files.indexing && r.files.total === {expected};'), timeout=120)
    r.evaluate('window.__memoryTraceEnabled=false; window.__memoryTrace.length=0; return true;')
    return pid, executable


def stage(pid, smoke):
    time.sleep(0.1 if smoke else 10)
    samples = []
    for index in range(1 if smoke else 5):
        if index:
            time.sleep(1)
        samples.append(r.sample(pid))
    values = [sum(p["footprint_bytes"] for p in s["processes"]) for s in samples]
    return {"samples": samples, "median_footprint_bytes": statistics.median(values)}


def ipc_queries(profile, smoke):
    cases = [["saf", "apps"], ["term", "apps"], ["12 * 8", "calculator"]]
    if profile == "daily":
        cases += [["document", "files"], ["café", "files"], ["folder-072", "files"], ["memory fixture", "clipboard"]]
    return r.evaluate('''
        const cases = CASES;
        const rows = [];
        for (let round = -2; round < ROUNDS; round++) {
            for (const [query, mode] of cases) {
                const started = performance.now();
                const result = await window.__memoryBackend.search(query, mode);
                const elapsed = performance.now() - started;
                if (!result.results.length) throw new Error(`Empty native results for ${mode}: ${query}`);
                rows.push({query,mode,round,ms:elapsed,results:result.results.map(r=>({id:r.id,title:r.title,score:r.score}))});
            }
        }
        return rows;
    '''.replace("CASES", json.dumps(cases)).replace("ROUNDS", "1" if smoke else "25"))


def ui_queries(profile, smoke):
    cases = [["Apps", "saf", "Safari"], ["Calculator", "12 * 8", "96"]]
    if profile == "daily":
        cases += [["Files", "document-001", "document-001.txt"], ["Files", "café-document-010", "café-document-010.txt"]]
    return r.evaluate('''
        const sleep = () => new Promise(resolve=>setTimeout(resolve, 1));
        const settled = async () => {
            const deadline=performance.now()+5000;
            while(document.querySelector('#search-results')?.getAttribute('aria-busy') !== 'false') {
                if(performance.now()>deadline) throw new Error('UI search timeout');
                await sleep();
            }
        };
        const input=document.querySelector('input[role=combobox]');
        const enter=value=>{input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));};
        const rows=[];
        for(let round=-2;round<ROUNDS;round++) {
            for(const [category,query,expected] of CASES) {
                const tab=[...document.querySelectorAll('.category-tab')].find(t=>t.textContent.trim()===category);
                if(!tab) throw new Error('Missing category '+category);
                if(tab.getAttribute('aria-pressed')!=='true') {tab.click();await settled();}
                enter('zzzxqvbenchmarknomatch');await settled();
                const started=performance.now();enter(query);await settled();
                const elapsed=performance.now()-started;
                const titles=[...document.querySelectorAll('.result-title')].map(t=>t.textContent);
                if(!titles.includes(expected)) throw new Error(JSON.stringify({query,expected,titles}));
                rows.push({category,query,round,ms:elapsed,titles});
            }
        }
        return rows;
    '''.replace("ROUNDS", "1" if smoke else "15").replace("CASES", json.dumps(cases)))


def smoke_clipboard():
    helper = subprocess.Popen([str(ROOT / "clipboard")], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    assert json.loads(helper.stdout.readline())["ready"]
    def ask(value):
        helper.stdin.write(json.dumps(value) + "\n")
        helper.stdin.flush()
        return json.loads(helper.stdout.readline())
    checks = {}
    try:
        preview = r.evaluate('return await window.__memoryBackend.clipboardPreview("clipboard:1");')
        assert preview["content"] == "memory fixture 000 " + "x" * 16365
        checks["preview_exact"] = True
        r.evaluate('await window.__memoryBackend.execute("clipboard:1","copy"); return true;')
        assert ask({"op": "matches", "text": preview["content"]})["matches"]
        checks["single_copy_exact"] = True
        error = r.evaluate('try{await window.__memoryBackend.copyClipboardSelection(Array(100).fill("clipboard:1"),"\\n");return null;}catch(e){return String(e);}')
        assert error == "The selected clipboard text is larger than 16384 bytes.", error
        assert ask({"op": "matches", "text": preview["content"]})["matches"]
        checks["oversized_rejected_without_clipboard_write"] = True
        ids=[]
        texts=["  Café 🚀\nfirst", "second"]
        for text in texts:
            r.command("clipboard", text=text)
            value=r.until(lambda: r.evaluate('const r=await window.__memoryBackend.search('+json.dumps(text.strip())+',"clipboard"); return r.results[0]?.id;'))
            r.until(lambda: r.evaluate('return (await window.__memoryBackend.clipboardPreview('+json.dumps(value)+')).content === '+json.dumps(text)+';'))
            ids.append(value)
        ordered=[ids[1],ids[0],ids[1]]
        r.evaluate('await window.__memoryBackend.copyClipboardSelection('+json.dumps(ordered)+',"\\n---\\n");return true;')
        expected="\n---\n".join([texts[1],texts[0],texts[1]])
        assert ask({"op":"matches","text":expected})["matches"]
        checks["ordered_duplicate_copy_exact"] = True
        error=r.evaluate('try{await window.__memoryBackend.copyClipboardSelection(["clipboard:999999"],"");return null;}catch(e){return String(e);}')
        assert error == "A clipboard entry is no longer available.",error
        assert ask({"op":"matches","text":expected})["matches"]
        checks["missing_id_rejected_without_clipboard_write"] = True
    finally:
        checks["restore"] = ask({"op":"restore"})
        helper.wait(timeout=10)
    return checks


def run(variant, profile, pair, smoke):
    directory=ROOT / "results" / ("smoke" if smoke else "native")
    directory.mkdir(exist_ok=True)
    output=directory/f"{pair}-{profile}-{variant}.json"
    assert not output.exists(), f"Refusing to replace {output}"
    data={"variant":variant,"profile":profile,"pair":pair,"smoke_only":smoke,"environment_before":environment()}
    pid=None
    print(f"Starting {variant} {profile} pair {pair}",flush=True)
    try:
        pid, executable=launch(variant,profile)
        data["pid"]=pid
        data["executable_sha256"]=hashlib.sha256(executable.read_bytes()).hexdigest()
        data["catalog"]=r.evaluate('return (await window.__memoryBackend.appCatalog()).map(r=>({id:r.id,title:r.title}));')
        r.command("hide")
        data["startup_hidden"]=stage(pid,smoke)
        r.command("show")
        data["ipc_queries"]=ipc_queries(profile,smoke)
        data["ui_queries"]=ui_queries(profile,smoke)
        data["visible_after_first_use"]=r.sample(pid)
        r.command("hide")
        data["first_use_hidden"]=stage(pid,smoke)
        r.command("settings")
        r.until(lambda:r.evaluate('return !!document.querySelector(".settings-fields");',"settings"))
        r.command("close",window="settings")
        r.until(lambda:not any(w["label"]=="settings" and w["visible"] for w in r.command("status")["windows"]))
        data["settings_hidden"]=stage(pid,smoke)
        r.command("show")
        r.evaluate('const tab=[...document.querySelectorAll(".category-tab")].find(t=>t.textContent.trim()==="All");tab.click();return true;')
        data["reopen"]=r.m.ui("summon",pid,1 if smoke else 20)
        data["sustained_queries"]=ipc_queries(profile,smoke)
        r.command("hide")
        data["sustained_hidden"]=stage(pid,smoke)
        if smoke and profile=="daily":
            data["clipboard_checks"]=smoke_clipboard()
            original=FIXTURE/"folder-000/document-001.txt"
            renamed=original.with_name("native-rename-check.txt")
            original.rename(renamed)
            try:
                r.until(lambda:r.evaluate('const r=await window.__memoryBackend.search("native-rename-check","files");return r.results.some(x=>x.title==="native-rename-check.txt");'),timeout=60)
                data["file_watch_rename"]=True
            finally:
                renamed.rename(original)
        data["status"]=r.command("status")
    except BaseException as error:
        data["error"]=f"{type(error).__name__}: {error}"
        raise
    finally:
        if pid and pid in r.m.processes():
            r.m.stop(pid)
            time.sleep(0.5)
            data["remaining_helpers"]=r.m.members(pid)
        data["environment_after"]=environment()
        data["app_log"]=(r.CONTROL/"app.log").read_text(errors="replace")
        write(output,data)
        print(output,flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("phase",choices=["prepare","smoke","measure"])
    parser.add_argument("--variant",choices=["baseline","candidate"])
    parser.add_argument("--pair",type=int,default=0)
    args=parser.parse_args()
    prepare()
    lock=(r.PROFILE/".memory-benchmark-lock").open("a")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if args.phase=="prepare":return
    if args.phase=="smoke":
        for variant in ([args.variant] if args.variant else ["baseline","candidate"]):
            run(variant,"daily",args.pair,True)
    else:
        rng=random.Random(20260920)
        plan=[]
        for pair in range(1,6):
            for profile in ["controlled","daily"]:
                variants=["baseline","candidate"]
                rng.shuffle(variants)
                plan.append({"pair":pair,"profile":profile,"order":variants})
        planfile=ROOT/"native-plan.json"
        assert not planfile.exists()
        write(planfile,{"created_at":time.time(),"seed":20260920,"pairs":plan,"settle_seconds":10,"samples_per_state":5,"sample_interval_seconds":1})
        for item in plan:
            for variant in item["order"]:
                run(variant,item["profile"],item["pair"],False)


if __name__=="__main__":
    main()
