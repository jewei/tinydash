# TinyDash memory optimization

Prepared against `jewei/tinydash` main at `06974f411483f5d254d80b617d9fcbe4dc114a71` on 20 September 2026. The patch changes five Rust files. Nothing was published or merged: the GitHub integration rejected the write with HTTP 403, `Resource not accessible by integration`.

## Apply

From a clean checkout of that revision, use the path where you extracted this bundle:

```sh
git switch -c perf/file-index-clipboard
git apply --check /path/to/tinydash-performance/changes.patch
git apply /path/to/tinydash-performance/changes.patch
```

The local changes are also available in the working checkout used for this task. Do not apply the patch a second time there.

## Changes

- File matching borrows existing ASCII filename/path bytes instead of keeping duplicate matcher strings. Unicode text and paths requiring separator conversion retain their normalized cache. IDs, original paths, matching scores, ordering, and action validation remain unchanged.
- Clipboard ID validation borrows entries. Preview and copy operations still produce the owned output they need. Multi-selection validates the combined size using borrowed entries before allocating output, with the search lock released before writing to the OS clipboard.
- Regression coverage checks shared storage, Unicode and whitespace matching, separators, usage ranking, result limits, oversized clipboard selections, and ordered/duplicate selection IDs.

## Measured allocation results

The isolated harness compiles the actual production provider and ranking source with Rust 1.98.1 on Linux x86-64. It measures requested Rust heap bytes with a tracking allocator. These figures exclude allocator overhead, fragmentation, filesystem traversal, Tauri, IPC, the webview, and native process RSS/physical footprint.

| Workload | Baseline bytes | Patched bytes | Reduction |
| --- | ---: | ---: | ---: |
| Retained file index: 50,000 ASCII paths | 16,540,000 | 13,645,000 | 17.5% / 2.76 MiB |
| Retained file index: 50,000 paths, 10% Unicode | 18,203,500 | 15,598,000 | 14.3% / 2.48 MiB |
| Peak additional heap: valid 100-item clipboard selection | 39,267 | 17,123 | 56.4% |
| Peak additional heap: rejected 100 × 16 KiB clipboard selection | 1,645,668 | 1,124 | 99.9% / 1.57 MiB |

Building the ASCII index made 150,001 allocation/reallocation requests instead of 650,001. Each measured clipboard selection made 7 requests instead of 107. File-search allocation traffic itself was unchanged; the main file benefit is retained index storage and index construction.

The file corpus uses Unix-style forward slashes. Windows paths requiring separator conversion still retain a normalized path cache, so their saving is smaller. Benefits depend on the size and character mix of the index. The clipboard saving is temporary allocation avoidance, not a reduction in retained clipboard history.

## Speed observations

Separate release binaries without the allocation tracker ran five alternating baseline/candidate blocks. Median index-construction time for 50,000 ASCII paths fell from **53.89 ms to 6.79 ms**; the mixed corpus fell from **67.82 ms to 26.88 ms**. These measure `FileProvider::new` only, excluding fixture construction and filesystem scanning.

Search timings were mixed and do not establish a general search speedup. For example, ASCII `doc` had median launch-level p50 of 4.89 ms before and after. Mixed-corpus `doc` had p50 7.554 → 7.464 ms, but p95 8.033 → 8.568 ms. ASCII no-match Unicode queries increased by about 0.04 ms. All raw observations are preserved; these small synthetic timing samples do not establish native latency non-inferiority.

## Verification and limits

- Baseline and candidate return identical ordered IDs and scores for eight queries over each 50,000-file corpus and 128 additional query/limit/usage combinations. The edge corpus includes composed/decomposed Unicode, tabs, LF/CRLF, Windows separators, emoji, and non-Latin text.
- Both clipboard workloads returned exactly the same text or error as the baseline.
- Nine isolated production unit tests passed: four clipboard-provider tests and five ranking tests. The provider tests include the new oversized-selection regression.
- The frontend production build, Prettier check, Rust formatting check, and patch whitespace check passed.
- The complete Tauri/Rust application, native launcher/storage integration, new file-provider tests in the desktop test target, and cross-platform desktop tests were not run. The environment lacks native GUI development dependencies, and GitHub write access prevented a branch/CI run.

Before merging, run the normal project checks in a desktop-capable environment:

```sh
cargo fmt --manifest-path src-tauri/Cargo.toml --check
cargo clippy --manifest-path src-tauri/Cargo.toml --all-targets --locked -- -D warnings
cargo test --manifest-path src-tauri/Cargo.toml --locked
bun run build
bun run test:ui
```

Total application memory and visible launcher latency still need the controlled native measurements described in the repository's `docs/performance-resume.md`. This patch makes no claim about those metrics and does not include the previous icon/window experiments.

## Evidence

`benchmark/` contains the portable core harness, pinned dependency lockfile, raw allocation/timing records, comparison summary, and reproduction commands. `clipboard-tests/` contains the isolated correctness harness. Supporting native types are explicitly stubbed; neither harness is a substitute for full application tests. `source-manifest.json` records the measured source hashes and patch hash.
