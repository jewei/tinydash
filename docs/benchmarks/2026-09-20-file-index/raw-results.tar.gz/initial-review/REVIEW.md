# TinyDash performance patch review

The patch has no confirmed code defect. The allocation benchmarks reproduce the reported memory savings exactly on this Mac. The Rust and UI test suites pass.

The review used commit `06974f411483f5d254d80b617d9fcbe4dc114a71` as the baseline. The candidate contained only the five-file patch from `tinydash-performance.zip`. The patch was applied to a temporary checkout. The main checkout remains unchanged, including the existing untracked file `docs/extensions-architecture-research.md`.

## Standards

No findings. The five-file patch does not violate the documented standards. The review found no actionable code smells.

All callers of `clipboard_entry`, `entries_for_ids`, and `combine_entries` use the required ownership. Each caller copies data when it needs an owned result. Borrowed entries remain within the search lock. The code releases this lock before it writes to the OS clipboard.

## Spec

No confirmed behavior defect was found. The changes stay within the stated scope.

The file index retains the original IDs and paths. The cached nucleo-matcher 0.3.1 source confirms that its owned ASCII input contains the same bytes as the new borrowed input. This includes control characters and CR/LF. Unicode normalization and Windows separator conversion retain the previous behavior. Unicode text that normalizes to ASCII still uses an owned cache.

The clipboard changes validate the combined size before copying selected payloads. Preview and copy operations still return owned data. Selection order, duplicate IDs, missing-ID validation, and action validation remain unchanged.

One performance acceptance requirement remains open. The repository's `docs/performance-resume.md` requires affected tests and controlled and daily-use native profiles before merge. This review completes the local test checks. It does not provide the required native profiles.

Standards review: zero findings. Spec review: zero code findings and one native measurement gap.

## Verified allocation results

Host: Apple M2, macOS 27.0, ARM64, Rust 1.98.1. Both variants use the supplied benchmark and its locked dependencies.

| Measurement | Baseline | Patch | Reduction |
| --- | ---: | ---: | ---: |
| Retained index, 50,000 ASCII paths | 16,540,000 bytes | 13,645,000 bytes | 17.5%, or 2.76 MiB |
| Retained index, 50,000 paths with 10% Unicode names | 18,203,500 bytes | 15,598,000 bytes | 14.3%, or 2.48 MiB |
| Peak extra heap, valid selection of 100 entries | 39,267 bytes | 17,123 bytes | 56.4% |
| Peak extra heap, rejected selection of 100 entries of 16 KiB each | 1,645,668 bytes | 1,124 bytes | 99.9%, or 1.57 MiB |

ASCII index construction made 150,001 allocation requests with the patch, compared with 650,001 before it. Each clipboard case made 7 requests with the patch, compared with 107 before it.

These numbers measure requested Rust heap bytes. They exclude allocator overhead, fragmentation, filesystem scanning, SQLite, Tauri, IPC, the webview, and native process memory. The clipboard reduction is temporary. It does not reduce retained clipboard history. The file corpus uses forward slashes. Windows paths that need separator conversion keep a path cache and save less memory.

Both variants returned identical ordered result IDs and scores for all measured queries, both 50,000-file corpora, and all five timing blocks. All 128 additional query, limit, and usage cases matched. Both clipboard cases returned identical text or errors. The new production test also compared full serialized file results with the previous owned representation.

## Timing evidence

The original Linux raw results support the stated ASCII constructor median of 53.891 ms before the patch and 6.787 ms after it. These times cover `FileProvider::new` only. They exclude fixture construction and filesystem scanning.

The local run used the same five alternating blocks and 100 measured searches per query. It produced an ASCII constructor median of 79.032 ms before the patch and 6.629 ms after it. Local mixed-corpus `doc` search medians were 8.987 ms before the patch and 14.073 ms after it. These local results are inconclusive.

The timings varied strongly between launches. For example, mixed-corpus `doc` p50 ranged from 6.374 to 13.004 ms for the baseline and from 6.558 to 20.004 ms for the patch. A process snapshot immediately after the run showed several busy iOS Simulator processes. Three used about 170%, 111%, and 69% CPU. The snapshot was taken after the measurements and does not establish load at each sample.

The local timing run cannot establish a search speedup, a search slowdown, or latency acceptance. All high and low samples remain in `results/`. No observation was removed. `summary.json` contains descriptive medians, not acceptance results. A controlled run on an idle host remains necessary for a search latency decision. Total application memory and visible launcher latency also remain unverified.

## Local checks

| Check | Result |
| --- | --- |
| Patch applies to the current commit | Pass |
| Bundle, baseline, candidate, and available benchmark hashes | Pass |
| Patch whitespace and Rust formatting | Pass |
| Clippy, all targets, with warnings rejected | Pass |
| Complete Rust test suite on macOS | 161 passed, 0 failed, 3 ignored |
| Prettier | Pass |
| Frontend production build | Pass |
| UI test suite | 132 passed, 0 failed |

The three ignored Rust tests are the installed-app icon check, the installed-app scan, and the separate 50,000-file SearchManager release profiler. The new file-provider and clipboard tests ran in the full application crate and passed.

Windows and Linux native builds and desktop UI tests did not run. The UI suite uses the repository's mock backend. It does not verify native clipboard IPC or OS clipboard behavior. The full Rust suite compiles the changed native callers, but it does not replace a desktop interaction test.

## Evidence and reproduction

- `bundle/` preserves all original archive contents, including the patch and source manifest.
- `manifest.json` records the local platform, compiler, patch hash, benchmark executable hashes, run order, and raw result hashes.
- `checks.json` records the check commands and their results.
- `logs/rust-tests.log`, `logs/ui-tests.log`, and `logs/format-check.log` preserve test output.
- `results/` contains the local raw allocation and timing records.
- `summary.json` contains the comparison and result-equivalence checks.
- `reproduce.py` builds, runs, and compares the unchanged supplied benchmark against two checkouts.

The original benchmark executables were not included in the archive. All 46 available entries in its benchmark hash manifest matched. All bundle hashes, the patch hash, and all ten changed source hashes also matched.

To reproduce, create a baseline checkout at the recorded commit and a second checkout with `bundle/changes.patch` applied. Run each phase with the corresponding paths:

```sh
python3 reproduce.py build --bundle ./bundle --baseline /path/to/baseline --candidate /path/to/candidate --scratch /path/to/temporary-build
python3 reproduce.py measure --bundle ./bundle --baseline /path/to/baseline --candidate /path/to/candidate --scratch /path/to/temporary-build
python3 reproduce.py summarize --bundle ./bundle --baseline /path/to/baseline --candidate /path/to/candidate --scratch /path/to/temporary-build
```

Use a fresh copy of this evidence directory for another run. The script writes its results beside itself. Run timing measurements after builds and tests finish, on an idle host. The temporary review checkout and benchmark build cache were removed after the evidence was saved. Their executable hashes remain in the manifest.
